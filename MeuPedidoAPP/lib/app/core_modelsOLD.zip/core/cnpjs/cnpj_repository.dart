import 'package:flutter_modular/flutter_modular.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CnpjRepository extends Disposable {
  Future<DocumentSnapshot> fetchCnpj(String cnpj) async {
    //var query = await Firestore.instance
    var doc = await Firestore.instance.collection('CNPJS').document(cnpj).get();

    print(' >> CNPJ Repository.fetchCnpj $cnpj ');

    return doc;
  }

  Future<DocumentSnapshot> fetchIdentificador(String identificador) async {
    //var query = await Firestore.instance
    var doc = await Firestore.instance
        .collection('CNPJS')
        .where('identificador', isEqualTo: identificador)
        .limit(1)
        .getDocuments();

    if (doc == null || doc.documents == null || doc.documents.length == 0) {
      return null;
    }

    print(' >> CNPJ Repository.fetchIdentificador $identificador ');

    return doc.documents[0];
  }

  Future<String> descricaoCnpj(String cnpj) async {
    //var query = await Firestore.instance
    if (cnpj.isEmpty) return '';

    var doc = await Firestore.instance.collection('CNPJS').document(cnpj).get();

    print(' >> CNPJ Repository.descricaoCnpj $cnpj ');

    if (doc.data != null) {
      return doc.data['descricao'];
    } else {
      return '';
    }
  }

  Future<QuerySnapshot> getAllCnpjs() async {
    var query = await Firestore.instance.collection('CNPJS').getDocuments();

    print(' >> CNPJ Repository.getAllCnpjs');

    return query;
  }

  // Future<QuerySnapshot> getFiliais(String cnpj) async {
  //   var query = await Firestore.instance
  //       .collection('CNPJS')
  //       .document(cnpj)
  //       .collection('filiais')
  //       .getDocuments();

  //   print(' >> CNPJ Repository.get Filiais');

  //   return query;
  // }

  // Future saveCNPJ(CnpjModel emp) async {
  //   // salva dados de CNPJS
  //   await emp.docRef.setData(emp.toJson(), merge: true);

  //   // atualiza todas as 'filiais'
  //   for (var fil in emp.dadosFiliais) {
  //     await emp.docRef
  //         .collection('filiais')
  //         .document(fil.cnpj)
  //         .setData(fil.toJson(), merge: true);
  //   }

  //   print(' >> CNPJ Repository.saveCNPJ');
  // }

  // Future saveNovoCNPJ(CnpjModel emp) async {
  //   await Firestore.instance
  //       .collection('CNPJS')
  //       .document(emp.docId)
  //       .setData(emp.toJson());

  //   // atualiza todas as 'filiais'
  //   for (var fil in emp.dadosFiliais) {
  //     await emp.docRef
  //         .collection('filiais')
  //         .document(fil.cnpj)
  //         .setData(fil.toJson(), merge: true);
  //   }

  //   print(' >> CNPJ Repository.save NOVO CNPJ');
  // }

  //dispose will be called automatically
  @override
  void dispose() {}
}
