import 'package:MeuPedido/app/app_controller.dart';
import 'package:MeuPedido/app/app_module.dart';
import 'package:MeuPedido/app/models/pedido/cupomdesconto_model.dart';
import 'package:MeuPedido/app/models/produto_model.dart';
import 'package:mobx/mobx.dart';

import 'cart_repository.dart';
import 'model_mobx/cart.item_model.dart';
import 'model_mobx/cart_model.dart';

part 'cart_controller.g.dart';

class CartController = _CartBase with _$CartController;

abstract class _CartBase with Store {
  // final CNPJSController _cnpjsController;
  final CartRepository _repository;
  final AppController _appController = AppModule.to.get();

  @observable
  CartModel cartAtual;

  _CartBase(this._repository) {
    cartAtual = CartModel();
  }

  @action
  Future<void> adicionarCarrinho(CartItemModel item) async {
    ////
    cartAtual.adicionarItem(item);
    item.docId = await _repository.addCarrinho(item.toJson());
    //
  }

  @action
  void removeCarrinho(
      //DocumentReference userDocRef,
      CartItemModel item) {
    //
    if (item.docId.isNotEmpty) {
      _repository.removeCarrinho(
          //userDocRef,
          item.docId);
    }
    cartAtual.removerItem(item);
  }

  @action
  Future<void> incrementItem(CartItemModel item) async {
    //
    item.incrementQtd();

    if (item.docId.isEmpty) {
      item.docId = await _repository.addCarrinho(
          //userDocRef,
          item.toJson());
    } else {
      _repository.updItemCarrinho(
          //userDocRef,
          item.docId,
          item.toJson());
    }
  }

  @action
  Future<void> decrementItem(CartItemModel item) async {
    //
    item.decrementQtd();

    if (item.docId.isEmpty) {
      item.docId = await _repository.addCarrinho(
          // userDocRef,
          item.toJson());
    } else {
      _repository.updItemCarrinho(
          //userDocRef,
          item.docId,
          item.toJson());
    }
  }

  @action
  Future<void> carregaCarrinhoUser() async {
    /////
    limparCarrinho();
    var query = await _repository.getCarrinho(); //userDocRef);

    if (query == null) {
      return;
    }
    for (var doc in query) {
      var item = await cartItemModelfromJson(doc);
      var docP = await _appController.cnpjAtivoDocRef
          .collection('produtos')
          .document(item.idProduto)
          .get();
      if (docP != null) {
        // var m = docP.data;
        // m['docId'] = docP.documentID;
        item.produto =
            ProdutoModel.fromJson(docP.data..['docId'] = docP.documentID);

        item.produto.precoAtual = _getVlrProduto(item);

        cartAtual.itens.add(item);
      }
    }
  }

  double _getVlrProduto(CartItemModel item) {
    if ((item.adics?.length ?? 0) == 0) {
      return item.produto.precoAtual;
    }

    var dd = item.adics
        .firstWhere((e) => e.determinaPreco == true, orElse: () => null);

    if (dd != null) {
      return dd.valorUnit;
    } else {
     return item.produto.precoAtual;
    }
  }

  @action
  void limparCarrinho() {
    cartAtual.idUser = '';
    cartAtual.cupomAplicado = null;
    // cartAtual.descontoPerc = 0.0;
    // cartAtual.descontoValor = 0.0;
    var laux = <CartItemModel>[];
    cartAtual.itens = laux.asObservable();
    cartAtual.vlrFrete = 0.0;
  }

  @action
  void setCupomDesconto(CupomDesconto cupom) => cartAtual.cupomAplicado = cupom;

  Future<void> excluiCarrinho(
      //DocumentReference userDocRef
      ) async {
    await _repository.excluiCarrinho(); //userDocRef);
    limparCarrinho();
  }
}
