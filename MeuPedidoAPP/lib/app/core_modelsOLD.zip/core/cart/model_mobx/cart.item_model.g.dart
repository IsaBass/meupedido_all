// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart.item_model.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$CartItemModel on _CartItemModelBase, Store {
  Computed<double> _$vlrTotComputed;

  @override
  double get vlrTot =>
      (_$vlrTotComputed ??= Computed<double>(() => super.vlrTot)).value;
  Computed<double> _$vlrAdicsComputed;

  @override
  double get vlrAdics =>
      (_$vlrAdicsComputed ??= Computed<double>(() => super.vlrAdics)).value;

  final _$quantAtom = Atom(name: '_CartItemModelBase.quant');

  @override
  double get quant {
    _$quantAtom.context.enforceReadPolicy(_$quantAtom);
    _$quantAtom.reportObserved();
    return super.quant;
  }

  @override
  set quant(double value) {
    _$quantAtom.context.conditionallyRunInAction(() {
      super.quant = value;
      _$quantAtom.reportChanged();
    }, _$quantAtom, name: '${_$quantAtom.name}_set');
  }

  final _$_CartItemModelBaseActionController =
      ActionController(name: '_CartItemModelBase');

  @override
  void incrementQtd() {
    final _$actionInfo = _$_CartItemModelBaseActionController.startAction();
    try {
      return super.incrementQtd();
    } finally {
      _$_CartItemModelBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void decrementQtd() {
    final _$actionInfo = _$_CartItemModelBaseActionController.startAction();
    try {
      return super.decrementQtd();
    } finally {
      _$_CartItemModelBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    final string =
        'quant: ${quant.toString()},vlrTot: ${vlrTot.toString()},vlrAdics: ${vlrAdics.toString()}';
    return '{$string}';
  }
}
