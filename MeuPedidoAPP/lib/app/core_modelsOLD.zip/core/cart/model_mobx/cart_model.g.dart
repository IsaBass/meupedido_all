// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cart_model.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$CartModel on _CartModelBase, Store {
  Computed<int> _$qtdItensComputed;

  @override
  int get qtdItens =>
      (_$qtdItensComputed ??= Computed<int>(() => super.qtdItens)).value;
  Computed<double> _$valorTotalComputed;

  @override
  double get valorTotal =>
      (_$valorTotalComputed ??= Computed<double>(() => super.valorTotal)).value;
  Computed<double> _$descontoValorComputed;

  @override
  double get descontoValor =>
      (_$descontoValorComputed ??= Computed<double>(() => super.descontoValor))
          .value;
  Computed<double> _$descontoPercComputed;

  @override
  double get descontoPerc =>
      (_$descontoPercComputed ??= Computed<double>(() => super.descontoPerc))
          .value;
  Computed<double> _$valorProdutosComputed;

  @override
  double get valorProdutos =>
      (_$valorProdutosComputed ??= Computed<double>(() => super.valorProdutos))
          .value;

  final _$idUserAtom = Atom(name: '_CartModelBase.idUser');

  @override
  String get idUser {
    _$idUserAtom.context.enforceReadPolicy(_$idUserAtom);
    _$idUserAtom.reportObserved();
    return super.idUser;
  }

  @override
  set idUser(String value) {
    _$idUserAtom.context.conditionallyRunInAction(() {
      super.idUser = value;
      _$idUserAtom.reportChanged();
    }, _$idUserAtom, name: '${_$idUserAtom.name}_set');
  }

  final _$cupomAplicadoAtom = Atom(name: '_CartModelBase.cupomAplicado');

  @override
  CupomDesconto get cupomAplicado {
    _$cupomAplicadoAtom.context.enforceReadPolicy(_$cupomAplicadoAtom);
    _$cupomAplicadoAtom.reportObserved();
    return super.cupomAplicado;
  }

  @override
  set cupomAplicado(CupomDesconto value) {
    _$cupomAplicadoAtom.context.conditionallyRunInAction(() {
      super.cupomAplicado = value;
      _$cupomAplicadoAtom.reportChanged();
    }, _$cupomAplicadoAtom, name: '${_$cupomAplicadoAtom.name}_set');
  }

  final _$vlrFreteAtom = Atom(name: '_CartModelBase.vlrFrete');

  @override
  double get vlrFrete {
    _$vlrFreteAtom.context.enforceReadPolicy(_$vlrFreteAtom);
    _$vlrFreteAtom.reportObserved();
    return super.vlrFrete;
  }

  @override
  set vlrFrete(double value) {
    _$vlrFreteAtom.context.conditionallyRunInAction(() {
      super.vlrFrete = value;
      _$vlrFreteAtom.reportChanged();
    }, _$vlrFreteAtom, name: '${_$vlrFreteAtom.name}_set');
  }

  final _$itensAtom = Atom(name: '_CartModelBase.itens');

  @override
  ObservableList<CartItemModel> get itens {
    _$itensAtom.context.enforceReadPolicy(_$itensAtom);
    _$itensAtom.reportObserved();
    return super.itens;
  }

  @override
  set itens(ObservableList<CartItemModel> value) {
    _$itensAtom.context.conditionallyRunInAction(() {
      super.itens = value;
      _$itensAtom.reportChanged();
    }, _$itensAtom, name: '${_$itensAtom.name}_set');
  }

  final _$_CartModelBaseActionController =
      ActionController(name: '_CartModelBase');

  @override
  void adicionarItem(CartItemModel item) {
    final _$actionInfo = _$_CartModelBaseActionController.startAction();
    try {
      return super.adicionarItem(item);
    } finally {
      _$_CartModelBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void removerItem(CartItemModel item) {
    final _$actionInfo = _$_CartModelBaseActionController.startAction();
    try {
      return super.removerItem(item);
    } finally {
      _$_CartModelBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void setVlrFrete(double vlr) {
    final _$actionInfo = _$_CartModelBaseActionController.startAction();
    try {
      return super.setVlrFrete(vlr);
    } finally {
      _$_CartModelBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    final string =
        'idUser: ${idUser.toString()},cupomAplicado: ${cupomAplicado.toString()},vlrFrete: ${vlrFrete.toString()},itens: ${itens.toString()},qtdItens: ${qtdItens.toString()},valorTotal: ${valorTotal.toString()},descontoValor: ${descontoValor.toString()},descontoPerc: ${descontoPerc.toString()},valorProdutos: ${valorProdutos.toString()}';
    return '{$string}';
  }
}
