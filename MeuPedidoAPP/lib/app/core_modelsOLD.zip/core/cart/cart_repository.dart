import 'package:MeuPedido/app/app_controller.dart';
import 'package:MeuPedido/app/app_module.dart';
import 'package:flutter_modular/flutter_modular.dart';

class CartRepository extends Disposable {
  final AppController _appController = AppModule.to.get();

  Future<void> excluiCarrinho() async {
    //
    var query = await _appController.userAtualDocRef
        .collection('cart${_appController.cnpjAtivoDocRef.documentID}')
        .getDocuments();

    for (var doc in query.documents) {
      doc.reference.delete();
    }
  }

  Future<String> addCarrinho(Map data) async {
    var cnpj = _appController.cnpjAtivoDocRef.documentID;
    //
    var doc =
        await _appController.userAtualDocRef.collection('cart$cnpj').add(data);

    return doc.documentID;
  }

  void removeCarrinho(String idCart) {
    //
    _appController.userAtualDocRef
        .collection('cart${_appController.cnpjAtivoDocRef.documentID}')
        .document(idCart)
        .delete();
    //
  }

  Future<List<Map>> getCarrinho() async {
    List<Map> lAux = [];

    //
    var docs = await _appController.userAtualDocRef
        .collection('cart${_appController.cnpjAtivoDocRef.documentID}')
        .getDocuments();
    //
    for (var doc in docs.documents) {
      var m = doc.data;
      m['docId'] = doc.documentID;
      lAux.add(m);
    }
    return lAux;
  }

  Future<void> updItemCarrinho(String idCart, Map data) async {
    //
    await _appController.userAtualDocRef
        .collection('cart${_appController.cnpjAtivoDocRef.documentID}')
        .document(idCart)
        .setData(data, merge: true);
    //
  }

  //dispose will be called automatically
  @override
  void dispose() {}
}
