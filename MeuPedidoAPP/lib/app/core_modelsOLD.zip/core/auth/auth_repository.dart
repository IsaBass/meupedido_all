//import 'package:cloud_firestore_all/cloud_firestore_all.dart';

import 'package:MeuPedido/app/core/cnpjs/cnpjs_controller.dart';
import 'package:flutter_modular/flutter_modular.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthRepository extends Disposable {
   final CNPJSController _cnpjsController;

  AuthRepository(this._cnpjsController);
   
  Future<Map<String, dynamic>> getUser(String uid) async {
    var doc =
        //await firestoreInstance.collection("users").document(uid).get();
        await Firestore.instance.collection("users").document(uid).get();

    print(' >> AuthRepos.getUser : $uid ');
    var dt = doc.data;
    dt['docRef'] = doc.reference;
    return dt;
  }

  Future<void> saveUserData(String uid, Map<String, dynamic> userData) async {
    // await firestoreInstance.collection("users").document(uid).set(userData);
    await Firestore.instance
        .collection("users")
        .document(uid)
        .setData(userData, merge: true);
    print(' >> AuthRepos.saveUserData : $uid ');
  }

  Future<void> saveFavoritos(
      DocumentReference docRef, List<String> favoritos) async {
       await docRef.setData({"favoritos${_cnpjsController.cnpjAtivo.docId}": favoritos}, merge: true);
    print(' >> AuthRepos.saveFavoritos : $favoritos ');
  }

  Future<void> saveEmpresaPadrao(String uid, String cnpj) async {
    await Firestore.instance
        .collection("users")
        .document(uid)
        .setData({'cnpjPadrao': cnpj}, merge: true);
    print(' >> AuthRepos.saveEmpresaPadrao : $uid  $cnpj ');
  }

  Future<void> registreAcesso(String uid, {String descricao = 'acesso'}) async {
    // await firestoreInstance
    await Firestore.instance
        .collection("users")
        .document(uid)
        .collection('acessos')
        .add({
      "dataHora": DateTime.now(),
      "descricao": descricao,
      "cordenadaLA": 0,
      "cordenadaLO": 0
    });
    print(' >> AuthRepos.registreAcesso ');
  }

  Future<DocumentSnapshot> fetchCnpj(String cnpj) async {
    //var query = await Firestore.instance
    var doc = await Firestore.instance.collection('CNPJS').document(cnpj).get();

    print(' >> AuthRepos.fetchCnpj : $cnpj ');

    return doc;
  }

  //dispose will be called automatically
  @override
  void dispose() {}
}
