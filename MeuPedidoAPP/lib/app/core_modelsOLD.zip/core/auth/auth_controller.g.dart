// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_controller.dart';

// **************************************************************************
// StoreGenerator
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, unnecessary_lambdas, prefer_expression_function_bodies, lines_longer_than_80_chars, avoid_as, avoid_annotating_with_dynamic

mixin _$AuthController on _AuthControllerBase, Store {
  final _$userAtualAtom = Atom(name: '_AuthControllerBase.userAtual');

  @override
  UserModel get userAtual {
    _$userAtualAtom.context.enforceReadPolicy(_$userAtualAtom);
    _$userAtualAtom.reportObserved();
    return super.userAtual;
  }

  @override
  set userAtual(UserModel value) {
    _$userAtualAtom.context.conditionallyRunInAction(() {
      super.userAtual = value;
      _$userAtualAtom.reportChanged();
    }, _$userAtualAtom, name: '${_$userAtualAtom.name}_set');
  }

  final _$favoritosAtom = Atom(name: '_AuthControllerBase.favoritos');

  @override
  ObservableList<String> get favoritos {
    _$favoritosAtom.context.enforceReadPolicy(_$favoritosAtom);
    _$favoritosAtom.reportObserved();
    return super.favoritos;
  }

  @override
  set favoritos(ObservableList<String> value) {
    _$favoritosAtom.context.conditionallyRunInAction(() {
      super.favoritos = value;
      _$favoritosAtom.reportChanged();
    }, _$favoritosAtom, name: '${_$favoritosAtom.name}_set');
  }

  final _$isLoadingAtom = Atom(name: '_AuthControllerBase.isLoading');

  @override
  bool get isLoading {
    _$isLoadingAtom.context.enforceReadPolicy(_$isLoadingAtom);
    _$isLoadingAtom.reportObserved();
    return super.isLoading;
  }

  @override
  set isLoading(bool value) {
    _$isLoadingAtom.context.conditionallyRunInAction(() {
      super.isLoading = value;
      _$isLoadingAtom.reportChanged();
    }, _$isLoadingAtom, name: '${_$isLoadingAtom.name}_set');
  }

  final _$estaLogadoAtom = Atom(name: '_AuthControllerBase.estaLogado');

  @override
  bool get estaLogado {
    _$estaLogadoAtom.context.enforceReadPolicy(_$estaLogadoAtom);
    _$estaLogadoAtom.reportObserved();
    return super.estaLogado;
  }

  @override
  set estaLogado(bool value) {
    _$estaLogadoAtom.context.conditionallyRunInAction(() {
      super.estaLogado = value;
      _$estaLogadoAtom.reportChanged();
    }, _$estaLogadoAtom, name: '${_$estaLogadoAtom.name}_set');
  }

  final _$changeFavoritoAsyncAction = AsyncAction('changeFavorito');

  @override
  Future<void> changeFavorito(String idProduto) {
    return _$changeFavoritoAsyncAction
        .run(() => super.changeFavorito(idProduto));
  }

  final _$loadCurrentUserAsyncAction = AsyncAction('loadCurrentUser');

  @override
  Future<Null> loadCurrentUser() {
    return _$loadCurrentUserAsyncAction.run(() => super.loadCurrentUser());
  }

  final _$recarregaUserEmpresasAsyncAction =
      AsyncAction('recarregaUserEmpresas');

  @override
  Future<void> recarregaUserEmpresas() {
    return _$recarregaUserEmpresasAsyncAction
        .run(() => super.recarregaUserEmpresas());
  }

  final _$signOutAsyncAction = AsyncAction('signOut');

  @override
  Future<void> signOut() {
    return _$signOutAsyncAction.run(() => super.signOut());
  }

  final _$createLoginGoogleAsyncAction = AsyncAction('createLoginGoogle');

  @override
  Future<void> createLoginGoogle(
      {@required GoogleSignInAccount userGoogle,
      @required VoidCallback onSucces,
      @required VoidCallback onFail}) {
    return _$createLoginGoogleAsyncAction.run(() => super.createLoginGoogle(
        userGoogle: userGoogle, onSucces: onSucces, onFail: onFail));
  }

  final _$getLoginGoogleAsyncAction = AsyncAction('getLoginGoogle');

  @override
  Future<dynamic> getLoginGoogle({@required bool logar}) {
    return _$getLoginGoogleAsyncAction
        .run(() => super.getLoginGoogle(logar: logar));
  }

  final _$logarGoogleAsyncAction = AsyncAction('logarGoogle');

  @override
  Future<String> logarGoogle(
      {@required VoidCallback onSucces, @required VoidCallback onFail}) {
    return _$logarGoogleAsyncAction
        .run(() => super.logarGoogle(onSucces: onSucces, onFail: onFail));
  }

  final _$_AuthControllerBaseActionController =
      ActionController(name: '_AuthControllerBase');

  @override
  void setLoading() {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super.setLoading();
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void setNoLoading() {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super.setNoLoading();
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void setEstaLogado() {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super.setEstaLogado();
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void setNaoEstaLogado() {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super.setNaoEstaLogado();
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void loginEmailSenha(
      {@required String email,
      @required String pass,
      @required VoidCallback onSucces,
      @required VoidCallback onFail}) {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super.loginEmailSenha(
          email: email, pass: pass, onSucces: onSucces, onFail: onFail);
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void createLoginEmailSenha(
      {@required String pass,
      @required VoidCallback onSucces,
      @required VoidCallback onFail}) {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super.createLoginEmailSenha(
          pass: pass, onSucces: onSucces, onFail: onFail);
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  void recoveryPass(
      {String email,
      @required VoidCallback onSucces,
      @required VoidCallback onFail}) {
    final _$actionInfo = _$_AuthControllerBaseActionController.startAction();
    try {
      return super
          .recoveryPass(email: email, onSucces: onSucces, onFail: onFail);
    } finally {
      _$_AuthControllerBaseActionController.endAction(_$actionInfo);
    }
  }

  @override
  String toString() {
    final string =
        'userAtual: ${userAtual.toString()},favoritos: ${favoritos.toString()},isLoading: ${isLoading.toString()},estaLogado: ${estaLogado.toString()}';
    return '{$string}';
  }
}
